OOD 2020L

# Structure of the data

You have to store data representing meetings of centaurs and minotaurs
that take place on pastures. There is an example xml document
conforming to the structure definition provided.

The document root is pastures. The first child of pastures is meetings
element and the subsequent child elements are minotaur, centaur and
pasture element in any order (possibly mixed with each other).

The meetings element contains **two** or more meeting elements.
Each meeting element has:
 - location attribute containing a reference to a name of a location
   (described later) -- required,
 - two or more participant elements containing a numeric identifier
   of a participant. Each participant id must be unique within a
   meeting. 
   
Each pasture element has:
 - area attribute -- a number (possibly a fraction) greater or equal
   to 1 -- required,
 - one or more name elements. Each name element must be unique across
   the whole document. Any name can be used to refer to the pasture. 
   The name must conform to the following format: one of more blocks
   consisting of two capital letters each. Blocks are separated with
   dashes. Example names: AA, AB-CD, EF-GG-HH.
   
   
Each centaur has: 
 - id -- an integer, required attribute,
 - name -- a string, required attribute,
 - age -- an integer, optional attribute,
 - at most three child elements in exactly that order. Each element is
   optional. Each element is empty.
   - beard,
   - mustache,
   - whiskers.

Each minotaur has:
 - id -- an integer, required attribute,
 - name -- a string, required attribute,
 - age -- an integer, optional attribute,
 - mass -- a number, optional attribute.
 
Id attributes of minotaurs and centaurs must be unique across *both*
kinds of creatures. 

# Notes on sending the solution

You have to send a complete xml, xsd and C# solution (with all project
files). Please remove any binary files before sending the solution.

# Detailed requirements


- (0.5 pts) Define XSD that will enforce the structure of the
  document. No keys and reference enforcement at this point.
  Modify XML so that elements are connected with XSD definition. 
- (0.5 pts) Avoid defining the common part of the types twice. 
- (0.5 pts) Write a program in \verb+C#+, that will read the XML given
  as a command line argument and print to stdout all meetings from
  file in the following format:
  Meeting in pasture of area [area] participants: (print names, not ids,
  of all participants)
- (0.5 pts) The solution is divided into separate project with class
  library and separate with console app.
- (0.5 pts) Classes are automatically generated from XSD during
  compilation process. 
- (0.5 pts) If the provided XML does not conform to XSD, the program
  prints an error message and exits. 
- (1 point) Enforce proper references from meetings to other entities.
- (1 point) Enforce unique participants in each meeting.
